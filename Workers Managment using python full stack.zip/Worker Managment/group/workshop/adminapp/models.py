from django.db import models

# Create your models here.
class Admin:
   
    name:str
    password:int

class Worker:

    name:str
    id:str
    job:str
    age:str
    mobile:str
    time:str
    day:str
    date:int