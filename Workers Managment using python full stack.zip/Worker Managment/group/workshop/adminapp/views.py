from urllib import request
from unittest import result
from django.shortcuts import render,redirect
import mysql.connector
from .models import Admin
from .models import Worker

from django.http import HttpResponse

def home(request):
    return render(request,'home.html')

def login(request):
    if request.method == 'POST':
        mydb = mysql.connector.connect(
		host = "localhost",
		user = "root",
		password = "",
		database = "workersmanagment"
		)
        mycursor = mydb.cursor()
        name=request.POST['name']
        pwd=request.POST['password']
        mycursor.execute("select * from admin where  name ='"+name+"' and password ='"+pwd+"'")
        result = mycursor.fetchone()
        if(result!=None):
            return redirect('addview')
        else:
            return render(request,'login.html',{'status':'invalid credentials'})
        
    else:
        return render(request,'login.html')


def about(request):
    return render(request,'about.html')

def contact(request):
    return render(request,'contact.html')

def register(request):
    if request.method == 'POST':
        mydb = mysql.connector.connect(
            host = "localhost",
            user = "root",
            password = "",
            database = "workersmanagment"
        )
        mycursor = mydb.cursor()
        name = request.POST['name']
        id = request.POST['id']
        job = request.POST['job']
        age = request.POST['age']
        mobile = request.POST['mobile']
        time = request.POST['time']
        day = request.POST['day']
        date = request.POST['date']
        mycursor.execute("insert into work(name,id,job,age,mobile,time,day,date)VALUES('"+name+"','"+id+"','"+job+"','"+age+"','"+mobile+"','"+time+"','"+day+"','"+date+"')")
        mydb.commit()
        return redirect ('addview')
    else:
        return render(request,'register.html')

def addview(request):
    return render(request,'addview.html')

def display(request):
    
    
    mydb = mysql.connector.connect(
    host = "localhost",
    user = "root",
    password = "",
    database = "workersmanagment"
    )
    mycursor = mydb.cursor()
    mycursor.execute("select * from work")
    result = mycursor.fetchall()
    work=[]
    for x in result:
        obj = Worker()
        obj.name=x[0]
        obj.id=x[1]
        obj.job=x[2]
        obj.age=x[3]
        obj.mobile=x[4]
        obj.time=x[5]
        obj.day=x[6]
        obj.date=x[7]
        work.append(obj)
    return render(request,'display.html',{'workinfo':work})
